import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import pylab

G = nx.Graph()

file_path = r'C:\python_projects\loc_rec2\yelp_data\aspect_categories.csv'

aspect_categories_dict = {}
fp = open(file_path, 'r')
lines = fp.readlines()
for line in lines[1:]:
    line = line.strip()
    aspect = line.split('|')[0]
    categories = line.split('|')[1].split(',')
    aspect_categories_dict.setdefault(aspect, categories)
    
aspect_aspect_w_dict = {}
for aspect1 in aspect_categories_dict:
    if aspect1 != "service":
        continue
    for aspect2 in aspect_categories_dict:
        if aspect1 == aspect2:
            continue
        cate1 = set(aspect_categories_dict[aspect1])
        cate2 = set(aspect_categories_dict[aspect2])
        overlap = cate1.intersection(cate2)
        uni = cate1.union(cate2)
        jaccard = float(len(overlap)) / len(uni)
        aspect_aspect_w_dict.setdefault((aspect1, aspect2), jaccard)

sort_dict = sorted(aspect_aspect_w_dict.items(), key=lambda value: value[1], reverse=True)

#G.add_edges_from([('A', 'B'),('C','D'),('G','D')], weight=1)
#G.add_edges_from([('D','A'),('D','E'),('B','D'),('D','E')], weight=2)
#G.add_edges_from([('B','C'),('E','F')], weight=3)
#G.add_edges_from([('C','F')], weight=4)
#
#
#val_map = {'A': 1.0,
#                   'D': 0.5714285714285714,
#                              'H': 0.0}
#
#values = [val_map.get(node, 0.45) for node in G.nodes()]
#edge_labels=dict([((u,v,),d['weight'])
#                 for u,v,d in G.edges(data=True)])
#red_edges = [('C','D'),('D','A')]
#edge_colors = ['black' if not edge in red_edges else 'red' for edge in G.edges()]
#
#pos=nx.spring_layout(G)
#nx.draw_networkx_edge_labels(G,pos,edge_labels=edge_labels)
#nx.draw(G,pos, node_color = values, node_size=1500,edge_color=edge_colors,edge_cmap=plt.cm.Reds)
#pylab.show()