# -*- coding: utf-8 -*-
"""
Created on Mon Dec 12 10:39:34 2016

@author: QGUO006
"""

import os
import json
import time

dir_path = r'C:\python_projects\loc_rec2\yelp_data3'

#"""
#1 - get the restaurants in Las Vegas
#"""
#filename1 = 'yelp_academic_dataset_business.json' #para: biz file of yelp
#rfile_path1 = os.path.join(dir_path, filename1)
#filename4 = 'restaurant_in_lv.csv' # para: the file name defined by the city
#wfile_path2 = os.path.join(dir_path, filename4)
#wfp2 = open(wfile_path2, 'w')
#rfp1 = open(rfile_path1, 'r')
#line = rfp1.readline()
#n1 = 0 # the number of biz
#n2 = 0 # the number of biz in Las Vegas
#n3 = 0 # the number of restaurants in Las Vegas
#restaurants_in_ch = []
#wfp2.write('biz|latitude|longitude|categories' + '\n')
#while line!='':
#    j = json.loads(line)
#    n1 += 1
#    if n1%100 == 0 and n1!=0:
#            print n1
#    if j['categories']!=[] and j['categories'][-1]=='Restaurants':
#        n2 += 1
#        if j['city'] == 'Charlotte': #para
#            biz = j['business_id']
#            restaurants_in_ch.append(biz)        
#            n3 += 1
#            lat = str(j['latitude'])
#            lon = str(j['longitude'])
#            categories = ','.join([str(c) for c in j['categories']])
#            field_list = [biz, lat, lon]
#            field_list.append(categories)
#            wfp2.write('|'.join(field_list) + '\n')
#    line = rfp1.readline()
#rfp1.close()
#wfp2.close()
#
#
#"""
#2 - get the reviews about restaurant in Las Vegas
#"""
#filename2 = 'review_restaurant_lv.csv' #para: the file name of reviews about restaurant in the city
#wfile_path1 = os.path.join(dir_path, filename2)
#wfp1 = open(wfile_path1, 'w')
#filename5 = 'restaurant_in_lv.csv' #para: the file name of restaurants in the city
#rfile_path4 = os.path.join(dir_path, filename5)
#filename3 = 'yelp_academic_dataset_review.json'
#rfile_path2 = os.path.join(dir_path, filename3)
#
##read the restaurant_in_ch file and get all restaurants
#rfp4 = open(rfile_path4, 'r')
#rest_in_ch = []
#lines = rfp4.readlines()
#rfp4.close()
#for line in lines:
#    line.strip()
#    field_list = line.split('|')
#    biz = field_list[0]
#    rest_in_ch.append(biz)
#
#review_list = []
#rfp2 = open(rfile_path2, 'r')
#line = rfp2.readline()
#c = 0
#wfp1.write("user|biz|review_id|stars|date|review"+'\n')
#while line!='':
#    j = json.loads(line)
#    if j['business_id'] in rest_in_ch:
#        user = str(j['user_id'])
#        biz = str(j['business_id'])
#        text = j['text']
#        text = text.encode('utf8')
#        stars = str(j['stars'])
#        review = str(text)
#        review = review.replace('\n', ' ')
#        review = review.replace('|', ' ')
#        date = str(j['date'])
#        review_id = str(j['review_id'])
#        line2 = '|'.join([user, biz, review_id, stars, date, review])
#        #review_list.append(line2)
#        wfp1.write(line2 + '\n')
#    if c%100 ==0:
#        print c
##    if c > 50000:
##        break
#    c += 1
#    line = rfp2.readline()
#rfp2.close()
#wfp1.close()
#
#
#"""
#3 - get high-quality data
#remove users with less than 10 reviews and remove items with less than 10 reviews
#First step: get all the reviews about restaurants in Las Vegas
#Second step: get all restaurants with more than 9 reviews, return qualified_line_by_rest
#Third step: get all users with more than 9 reviews from qualified_line_by_rest
#return qualified_line_by_rest_user => file: qualified_review_rest_lv.csv
#"""
#
#filename6 = 'review_restaurant_lv.csv' #para
#rfile_path3 = os.path.join(dir_path, filename6)
#rfp3 = open(rfile_path3, 'r')
#lines = rfp3.readlines()
#rfp3.close()
#rest_review_dict = {}
## the format of a line is: user|biz|review_id|date|review
#for line in lines[1:]:
#    line = line.strip()
#    field_list = line.split('|')
#    rest = field_list[1]
#    review_id = field_list[2]
#    if rest not in rest_review_dict:
#        rest_review_dict.setdefault(rest, [review_id])
#    else:
#        rest_review_dict[rest].append(review_id)
#print "scan rest over"
#
#qualified_rest = []
#for rest in rest_review_dict:
#    if len(rest_review_dict[rest]) > 9:
#        qualified_rest.append(rest)
#
#qualified_line_by_rest = []
#for line in lines[1:]:
#    field_list = line.split('|')
#    rest = field_list[1]
#    if rest in qualified_rest:
#        qualified_line_by_rest.append(line)
#print "add qualified line by rest"
#
#user_review_dict = {}
## the format of a line is: user|biz|review_id|date|review
#for line in qualified_line_by_rest:
#    line = line.strip()
#    field_list = line.split('|')
#    user = field_list[0]
#    review_id = field_list[2]
#    if user not in user_review_dict:
#        user_review_dict.setdefault(user, [review_id])
#    else:
#        user_review_dict[user].append(review_id)
#print "scan user over"
#
#qualified_user = []
#for user in user_review_dict:
#    if len(user_review_dict[user]) > 9:
#        qualified_user.append(user)
#
#qualified_line_by_rest_user = []
#for line in qualified_line_by_rest:
#    field_list = line.split('|')
#    user = field_list[0]
#    if user in qualified_user:
#        qualified_line_by_rest_user.append(line)
#print "add qualifed user"
#
#filename7 = 'qualified_review_rest_lv.csv'
#wfile_path7 = os.path.join(dir_path, filename7)
#wfp7 = open(wfile_path7, 'w')
#wfp7.write('user|biz|review_id|stars|date|review' + '\n')
#for line in qualified_line_by_rest_user:
#    wfp7.write(line)
#wfp7.close()
#
#
#"""
#4 - this part is to get the train and test data from qualified_review_rest_lv.csv
#First, save records of each user into a dictionary
#Secord, sort the reviews of each user chronologically
#Third, first 80% of the reviews of each user are saved as training dataset
#while another remaining 20% of the reviews are saved as test dataset
#the records would be stored in dictionary: {user_id: {review_id:time}}
#get the review_id of each users for train and test dataset
#"""
#filename = 'qualified_review_rest_lv.csv' #para
#filepath = os.path.join(dir_path, filename)
#rfp = open(filepath, 'r')
#lines= rfp.readlines()
#
#c = 0
#user_review_dict = {}
#for line in lines[1:]:
#    field_list = line.split('|') #user|biz|review_id|stars|date|review
#    user_id = field_list[0]
#    review_id = field_list[2]
#    date = field_list[4]
#    date2 = time.strptime(date, "%Y-%m-%d")
#    if user_id not in user_review_dict:
#        review_date = {}
#        review_date.setdefault(review_id, date2)
#        user_review_dict.setdefault(user_id, review_date)
#    else:
#        user_review_dict[user_id].setdefault(review_id, date2)
#    c += 1
#    if c%100 == 0:
#        print c
#
#user_review_dict2 = {}
#for user_id in user_review_dict:
#    review_date_list = user_review_dict[user_id]
#    sorted_review_date_list = sorted(review_date_list.items(), key=lambda x:x[1])
#    train_num = int(0.8 * len(sorted_review_date_list))
#    train_list = [sorted_review_date_list[i][0] for i in range(0, train_num)]
#    user_review_dict2.setdefault(user_id, train_list)
#
#train_file = "train_lv.csv" #para
#test_file = "test_lv.csv" #para
#train_filepath = os.path.join(dir_path, train_file)
#test_filepath = os.path.join(dir_path, test_file)
#wfp2 = open(train_filepath, 'w')
#wfp2.write('user|biz|review_id|stars|date|review' + '\n')
#wfp3 = open(test_filepath, 'w')
#wfp3.write('user|biz|review_id|stars|date|review' + '\n')
#c = 0
#for line in lines[1:]:
#    field_list = line.split('|') #user|biz|review_id|stars|date|review
#    user_id = field_list[0]
#    review_id = field_list[2]
#    if review_id in user_review_dict2[user_id]:
#        wfp2.write(line)
#    else:
#        wfp3.write(line)
#    c += 1
#    if c%100 == 0:
#        print c
#wfp2.close()
#wfp3.close()
#
#
#"""
#5 - get the friends of each user
#get the friends of each user in train set
#"""    
#filename6 = 'train_lv.csv' #para
#rfile_path3 = os.path.join(dir_path, filename6)
#rfp3 = open(rfile_path3, 'r')
#lines = rfp3.readlines()
#users = [line.split('|')[0] for line in lines[1:]]
#
#filename8 = 'yelp_academic_dataset_user.json' #para
#rfile_path4 = os.path.join(dir_path, filename8)
#rfp4 = open(rfile_path4, 'r')
#lines2 = rfp4.readlines()
#user_friend_dict = {}
#c = 0
#for line in lines2: 
#    j = json.loads(line)
#    user = str(j['user_id'])
#    if user in users:
#        friends = [str(f) for f in j['friends'] if str(f) in users]
#        user_friend_dict.setdefault(user, friends)
#        c += 1
#        if c%100 == 0:
#            print c
#print "over"
#
#filename9 = 'friends_lv.csv' #para
#wfile_path4 = os.path.join(dir_path, filename9)
#wfp4 = open(wfile_path4, 'w')
#wfp4.write('user|friends' + '\n')
#for user in user_friend_dict:
#    friends = ','.join(user_friend_dict[user])
#    line = '|'.join([user, friends]) + '\n'
#    wfp4.write(line)
#wfp4.close()
#print "write friends"
#
#        
"""
6 - get the sample dataset
this part is to get the sample data from train, test and friends datasets.
the number of users scanned is setting as sample2_num, but the total number might be
larger than this number since friends of the last users also included. the sampling
starts with a user and the scanning spreads across the social link which stops when
the number of users exceeds a certain level.
"""
filename1 = 'train_lv.csv' #para
filepath1 = os.path.join(dir_path, filename1)

filename2 = 'friends_lv.csv' #para
filepath2 = os.path.join(dir_path, filename2)

filename3 = 'sample2_train_lv.csv' #para
filepath3 = os.path.join(dir_path, filename3)

filename4 = 'sample2_test_lv.csv' #para
filepath4 = os.path.join(dir_path, filename4)

filename5 = 'sample2_friends_lv.csv' #para
filepath5 = os.path.join(dir_path, filename5)

filename6 = 'test_lv.csv' #para
filepath6 = os.path.join(dir_path, filename6)

sample2_num = 3200 #para

rfp1 = open(filepath1, 'r')
rfp2 = open(filepath2, 'r')
lines1 = rfp1.readlines() # train_lv.csv, user|biz|review_id|stars|date|review
rfp1.close()
lines2 = rfp2.readlines() # friends_lv.csv, user|friends
rfp2.close()
rfp3 = open(filepath6, 'r') 
lines3 = rfp3.readlines() # test_lv.csv
rfp3.close()

#get the records of users in training set
train_user_record_dict = {}
for line in lines1[1:]:
    field_list = line.split('|')
    user = field_list[0]
    if user not in train_user_record_dict:
        train_user_record_dict.setdefault(user, [line])
    else:
        train_user_record_dict[user].append(line)

#get the records of users in testing set
test_user_record_dict = {}
for line in lines3[1:]:
    field_list = line.split('|')
    user = field_list[0]
    if user not in test_user_record_dict:
        test_user_record_dict.setdefault(user, [line])
    else:
        test_user_record_dict[user].append(line)

users = [] 
user_friends_dict = {}
for line in lines2[1:]:
    field_list = line.split('|')
    user = field_list[0]
    friends = field_list[1].strip().split(',')
    user_friends_dict.setdefault(user, friends)    
    users.append(user)
    if field_list[1].strip() != '':
        users.extend(friends)
    if len(set(users)) > sample2_num:
        break
users = list(set(users))

wfp1 = open(filepath3, 'w') #sample2_train_lv.csv
wfp1.write('user|biz|review_id|stars|date|review\n')
wfp2 = open(filepath4, 'w') #sample2_test_lv.csv
wfp2.write('user|biz|review_id|stars|date|review\n')
wfp3 = open(filepath5, 'w') #sample2_friends_lv.csv
wfp3.write('user|friends\n')
for user in users:
    train_records = train_user_record_dict[user]
    for tr1 in train_records:
        wfp1.write(tr1)
    test_records = test_user_record_dict[user]    
    for tr2 in test_records:
        wfp2.write(tr2)
    if user in user_friends_dict:
        friends = ','.join(user_friends_dict[user])
    else:
        friends = ','.join([])
    line = '|'.join([user, friends]) + '\n'
    wfp3.write(line)
wfp1.close()
wfp2.close()
wfp3.close()
#

"""
7 - combine the reviews for one biz
a user may visti a biz for more than one time. here these records of one biz
are combined into one. the stars are averaged and reviews are concatenated into one
with #.
"""
filename1 = 'sample2_train_lv.csv' #para
filepath1 = os.path.join(dir_path, filename1)

filename2 = 'sample2_test_lv.csv' #para
filepath2 = os.path.join(dir_path, filename2)

rfp1 = open(filepath1, 'r')
lines1 = rfp1.readlines()
rfp2 = open(filepath2, 'r')
lines2 = rfp2.readlines()

user_biz_star_review_dict = {}
for line in lines1[1:]: 
    line = line.strip() # user|biz|review_id|stars|date|review   
    line = line.replace('\t', ' ')
    line = line.replace('#', ' ')
    field_list = line.split('|')
    user = field_list[0]
    biz = field_list[1]
    star = field_list[3]
    review = field_list[5]
    if user not in user_biz_star_review_dict:
        biz_star_review_dict = {}
        biz_star_review_dict.setdefault(biz, [(star, review)])
        user_biz_star_review_dict.setdefault(user, biz_star_review_dict)
    else:
        if biz not in user_biz_star_review_dict[user]:
            user_biz_star_review_dict[user].setdefault(biz, [(star, review)])
        else:
            user_biz_star_review_dict[user][biz].append((star, review))
print "get all the records of users into a dictionary"
     
user_biz_star_review_average_dict = {}                   
for user in user_biz_star_review_dict:
    biz_star_review_dict = user_biz_star_review_dict[user]
    biz_star_review_average_dict = {}
    for biz in biz_star_review_dict:
        sum_star = 0.0
        review_list = []
        star_review_list = biz_star_review_dict[biz]
        for sr in star_review_list:
            sum_star += float(sr[0])
            review_list.append(sr[1])
        average_star = sum_star/len(star_review_list)
        reviews = '#'.join(review_list)
        biz_star_review_average_dict.setdefault(biz, (average_star, reviews))
    user_biz_star_review_average_dict.setdefault(user, biz_star_review_average_dict)

filename3 = 'final_sample2_train_lv.csv' #para
filepath3 = os.path.join(dir_path, filename3)
wfp1 = open(filepath3, 'w')
wfp1.write('user|biz|star|reviews\n')
for user in user_biz_star_review_average_dict:
    biz_star_review_average_dict = user_biz_star_review_average_dict[user]
    line = ''
    for biz in biz_star_review_average_dict:
        average_star = biz_star_review_average_dict[biz][0]
        reviews = biz_star_review_average_dict[biz][1]
        line = '|'.join([user, biz, str(average_star), reviews]) + '\n'
        wfp1.write(line)
wfp1.close()
print "final train finish"

user_biz_dict = {}
for line in lines2[1:]:
    line = line.strip() # user|biz|review_id|stars|date|review   
    line = line.replace('\t', ' ')
    line = line.replace('#', ' ')
    field_list = line.split('|')
    user = field_list[0]
    biz = field_list[1]
    if user not in user_biz_dict:
        user_biz_dict.setdefault(user, [biz])
    else:
        if biz not in user_biz_dict[user]:
            user_biz_dict[user].append(biz)
    
filename4 = 'final_sample2_test_lv.csv' #para
filepath4 = os.path.join(dir_path, filename4)
wfp2 = open(filepath4, 'w')
wfp2.write('user|biz')
for user in user_biz_dict:
    biz_list = user_biz_dict[user]
    user_biz_list = [user]
    user_biz_list.extend(biz_list)
    wfp2.write('|'.join(user_biz_list) + '\n')
wfp2.close()
print "final_test_ch finish"


"""
8 - combine the reviews for one biz
a user may visti a biz for more than one time. here these records of one biz
are combined into one. the stars are averaged and reviews are concatenated into one
with #.
"""
filename1 = 'sample2_train_lv.csv' #para
filepath1 = os.path.join(dir_path, filename1)

filename2 = 'sample2_test_lv.csv' #para
filepath2 = os.path.join(dir_path, filename2)

rfp1 = open(filepath1, 'r')
lines1 = rfp1.readlines()
rfp2 = open(filepath2, 'r')
lines2 = rfp2.readlines()

user_biz_star_review_dict = {}
for line in lines1[1:]: 
    line = line.strip() # user|biz|review_id|stars|date|review   
    line = line.replace('\t', ' ')
    line = line.replace('#', ' ')
    field_list = line.split('|')
    user = field_list[0]
    biz = field_list[1]
    star = field_list[3]
    review = field_list[5]
    if user not in user_biz_star_review_dict:
        biz_star_review_dict = {}
        biz_star_review_dict.setdefault(biz, [(star, review)])
        user_biz_star_review_dict.setdefault(user, biz_star_review_dict)
    else:
        if biz not in user_biz_star_review_dict[user]:
            user_biz_star_review_dict[user].setdefault(biz, [(star, review)])
        else:
            user_biz_star_review_dict[user][biz].append((star, review))
print "get all the records of users into a dictionary"
     
user_biz_star_review_average_dict = {}                   
for user in user_biz_star_review_dict:
    biz_star_review_dict = user_biz_star_review_dict[user]
    biz_star_review_average_dict = {}
    for biz in biz_star_review_dict:
        sum_star = 0.0
        review_list = []
        star_review_list = biz_star_review_dict[biz]
        for sr in star_review_list:
            sum_star += float(sr[0])
            review_list.append(sr[1])
        average_star = sum_star/len(star_review_list)
        reviews = '#'.join(review_list)
        biz_star_review_average_dict.setdefault(biz, (average_star, reviews))
    user_biz_star_review_average_dict.setdefault(user, biz_star_review_average_dict)

filename3 = 'final_sample2_train_lv.csv' #para
filepath3 = os.path.join(dir_path, filename3)
wfp1 = open(filepath3, 'w')
wfp1.write('user|biz|star|reviews\n')
for user in user_biz_star_review_average_dict:
    biz_star_review_average_dict = user_biz_star_review_average_dict[user]
    line = ''
    for biz in biz_star_review_average_dict:
        average_star = biz_star_review_average_dict[biz][0]
        reviews = biz_star_review_average_dict[biz][1]
        line = '|'.join([user, biz, str(average_star), reviews]) + '\n'
        wfp1.write(line)
wfp1.close()
print "final sample train finish"

user_biz_dict = {}
for line in lines2[1:]:
    line = line.strip() # user|biz|review_id|stars|date|review   
    line = line.replace('\t', ' ')
    line = line.replace('#', ' ')
    field_list = line.split('|')
    user = field_list[0]
    biz = field_list[1]
    if user not in user_biz_dict:
        user_biz_dict.setdefault(user, [biz])
    else:
        if biz not in user_biz_dict[user]:
            user_biz_dict[user].append(biz)
    
filename4 = 'final_sample2_test_lv.csv' #para
filepath4 = os.path.join(dir_path, filename4)
wfp2 = open(filepath4, 'w')
wfp2.write('user|biz')
for user in user_biz_dict:
    biz_list = user_biz_dict[user]
    user_biz_list = [user]
    user_biz_list.extend(biz_list)
    wfp2.write('|'.join(user_biz_list) + '\n')
wfp2.close()
print "final sample test finish"
    

"""
9 - prepare reviews for aspects extraction
for aspect extraction, the tool, Minipar cannot handle long sentence. and a review
often has several sentences which is so long for Minipar to process. this part is to
separate these sentences in one review by use NLTK lib.
"""
#from nltk.tokenize import sent_tokenize
#
#filename1 = 'final_train_lv.csv'
#lines = open(os.path.join(dir_path, filename1), 'r').readlines()
#reviewNum_sentNum_dict = {}
#sentences_list = []
#n1 = 1
#n2 = 0
#filename2 = 'review.ch.raw'
#wfp = open(os.path.join(dir_path, filename2), 'w')
#for line in lines[1:]:
#    field_list = line.strip().split('|')
#    review = field_list[-1]
#    wfp.write("<DOC>\n")
#    review = str(review) + '\n'
#    wfp.write(review)
#    wfp.write("</DOC>\n")
#
##    sentences = sent_tokenize(review)
##    for s in sentences:
##        if 1<len(list(s)) < 1001:
##            sentences_list.append(s)
##            n2 += 1
##    reviewNum_sentNum_dict.setdefault(n1, n2)
##    n1 += 1
#
#wfp.close()

#wfp1 = open(os.path.join(dir_path, filename2), 'w')
#filename3 = 'review_sentence_map.csv'
#wfp2 = open(os.path.join(dir_path, filename3), 'w')
#for sentence in sentences_list:
#    wfp.write("<DOC>\n")
#    wfp1.write(str(sentence.encode('utf8')) + '\n')
#    wfp.write("</DOC>\n")
#    wfp.close()
#    
#wfp1.close()
#for reviewNum in reviewNum_sentNum_dict:
#    sentNum = reviewNum_sentNum_dict[reviewNum]
#    line = str(reviewNum) + ',' + str(sentNum) + '\n'
#    wfp2.write(line)
#wfp2.close()


