path = r'C:\python_projects\loc_rec2\yelp_data\aspect_categories.csv'

import os

fp = open(path, 'r')

lines = fp.readlines()
fp.close()

cate_list = []

for line in lines[1:]:
    categories = line.strip().split('|')[1]
    cates = categories.split(',')
    cate_list.extend(cates)
    
print len(set(cate_list))



# ch: 140

# lv 165

# ph: 