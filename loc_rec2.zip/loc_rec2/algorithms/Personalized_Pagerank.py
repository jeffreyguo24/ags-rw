# -*- coding: utf-8 -*-
"""
Created on Fri Dec 23 13:51:59 2016

@author: QGUO006
"""

import networkx as nx
import os

def construct_graph(train_file, friends_file):
    "construct graph from train and friends datastet"
    
    print "===construct_graph==="
    
    G = nx.Graph() # networkx will transfer graph into directed graph
    fp1 = open(friends_file, 'r')
    lines = fp1.readlines()
    fp1.close()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        friends = field_list[1].split(',')
        for f in friends:
            G.add_edge(user, f)
    print "finish scan friends file"
    
    fp2 = open(train_file, 'r')
    lines = fp2.readlines() #user|biz|star|reviews
    fp2.close()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        biz = field_list[1]
        G.add_edge(user, biz)
    print  "finish scan train file"
    return G

 
def topK_recommend(userNum, k, G, biz_file, train_file, recommendation_file):
    '''this method is to run personalized pagerank'''    
    
    print "===topK_recommend==="
    user_biz_star_dict = {}
    user_list = []
    fp1 = open(train_file, 'r')
    lines = fp1.readlines() #user|biz|star|reviews
    fp1.close()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        if user not in user_list:
            user_list.append(user)
        biz = field_list[1]
        star = field_list[2]
        if user not in user_biz_star_dict:
            user_biz_star_dict.setdefault(user, [(biz, star)])
        else:
            user_biz_star_dict[user].append((biz, star))
    print  "finish scan train file"
    
    users = [n for n in G.nodes() if n in user_list]
    user_rec_list_dict = {}
    i = 0
    if userNum>len(users):
        userNum = len(users)
    for u in users[:userNum]:
        print "topK_recommend: ", i
        i += 1
        user_rec_list_dict.setdefault(u, {})
        personalized_vector_dict = {}
        biz_list = [bs[0] for bs in user_biz_star_dict[u]]
        for entity in G.nodes():
            if entity in biz_list:
                personalized_vector_dict.setdefault(entity, 1.0) # nx will do the normalization
            elif entity == u:
                personalized_vector_dict.setdefault(entity, 1.0)
            else:
                personalized_vector_dict.setdefault(entity, 0.0)
        pr_dict = nx.pagerank(G, personalization=personalized_vector_dict)
        print "get pr_dict"
        sorted_pr_list = sorted(pr_dict.items(), key = lambda x:x[1], reverse = True)
        for s in sorted_pr_list:
            entity = s[0]
            score = s[1]
            if entity in [n for n in G.nodes() if n not in users]:
                user_rec_list_dict[u].setdefault(entity, score)
    print "generate recommendations"
    
    fp3 = open(recommendation_file, 'w')
    for u in user_rec_list_dict:
        biz_score_dict = user_rec_list_dict[u]
        sorted_biz_score_list = sorted(biz_score_dict.items(), key = lambda x:x[1], reverse = True)
        for biz_score in sorted_biz_score_list[:k]:
            biz = biz_score[0]
            score = biz_score[1]
            line = '|'.join([u, biz, str(score)]) + '\n'
            fp3.write(line)
    fp3.close()
    print "finish writing the recommendations into a file"


def get_eval_results(k, recommendation_file, test_file, result_file):
    '''calculate evaluation results'''
    
    print "===get_eval_results==="
    fp1 = open(recommendation_file, 'r')
    lines = fp1.readlines()
    fp1.close()
    
    user_rec_list_dict = {}
    for line in lines:
        field_list = line.strip().split('|')
        user = field_list[0]
        biz  =field_list[1]
        if user not in user_rec_list_dict:
            user_rec_list_dict.setdefault(user, [biz])
        else:
            user_rec_list_dict[user].append(biz)
    for user in user_rec_list_dict:
        user_rec_list_dict[user] = user_rec_list_dict[user][:k]
    print "get the recommendations of each user"
    
    fp2 = open(test_file, 'r')
    lines = fp2.readlines() #user|biz
    fp2.close()
    user_testBiz_dict = {}
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        testBiz_list = field_list[1:]
        user_testBiz_dict.setdefault(user, testBiz_list)
    print "get the test biz of each user"
    
    precision = 0.0
    recall = 0.0
    for user in user_rec_list_dict:
        rec_list = user_rec_list_dict[user]
        testBiz_list = user_testBiz_dict[user]
        hitNum = len([r for r in rec_list if r in testBiz_list])
        p = float(hitNum)/k
        re = float(hitNum)/len(testBiz_list)
        precision += p
        recall += re
    precision = precision/len(user_rec_list_dict)
    recall = recall/len(user_rec_list_dict)
    
    fp3 = open(result_file, 'w')
    fp3.write("topK|precision|recall\n")
    fp3.write('|'.join([str(k), str(precision), str(recall)]) + '\n')
    print "write the eval results into a file"
    

if __name__ == '__main__':
    dir_path = r'C:\python_projects\loc_rec2\yelp_data'
    train_file = os.path.join(dir_path, 'final_train_ph.csv') #sample
    friends_file = os.path.join(dir_path, 'friends_ph.csv') #sample
    G = construct_graph(train_file, friends_file)
    dir_result_path = r'C:\python_projects\loc_rec2\yelp_data\results'    
    recommendation_file = os.path.join(dir_result_path, 'PPR_recommendation.csv') #sample
    userNum = 20000 # if want to eval all user； userNum = len(G.nodes())
    k = 10 # topK
    biz_file = os.path.join(dir_path, 'restaurant_in_Ph.csv')    
    user_rec_list_dict = topK_recommend(userNum, k, G, biz_file, train_file, recommendation_file)
    test_file = os.path.join(dir_path, 'final_test_ph.csv') #sample
    result_file = os.path.join(dir_result_path, 'PPR_result.csv') #sample
    get_eval_results(k, recommendation_file, test_file, result_file)