# -*- coding: utf-8 -*-
"""
Created on Fri Dec 23 13:52:33 2016

@author: QGUO006
"""

import os
import networkx as nx
    

def get_similarity(list1, list2):
    '''get the overlapped element number of these two lists'''
    
    c = len([r for r in list1 if r in list2])
    return c
    

def construct_graph(train_file):
    "construct graph from train and friends datastet"
    
    print "===construct_graph==="
    
    biz_user_dict = {}
    fp1 = open(train_file, 'r')
    lines = fp1.readlines() #user|biz|star|reviews
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        biz = field_list[1]
        if biz not in biz_user_dict:
            biz_user_dict.setdefault(biz, [user])
        else:
            biz_user_dict[biz].append(user)
    fp1.close()
    print  "finish scan train file"

    G = nx.DiGraph()
    for biz1 in biz_user_dict:
        user_list1 = biz_user_dict[biz1]
        for biz2 in biz_user_dict:
            if biz1 == biz2:
                continue
            user_list2 = biz_user_dict[biz2]
            c = get_similarity(user_list1, user_list2)
            if c == 0:
                continue
            G.add_edge(biz1, biz2, weight = c)
    return G

 
def topK_recommend(userNum, k, G, biz_file, train_file, recommendation_file):
    '''this method is to run personalized pagerank'''    
    
    print "===topK_recommend==="
    user_biz_star_dict = {}
    user_list = []
    fp1 = open(train_file, 'r')
    lines = fp1.readlines() #user|biz|star|reviews
    fp1.close()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        if user not in user_list:
            user_list.append(user)
        biz = field_list[1]
        star = field_list[2]
        if user not in user_biz_star_dict:
            user_biz_star_dict.setdefault(user, [(biz, star)])
        else:
            user_biz_star_dict[user].append((biz, star))
    print  "finish scan train file"
    
    user_rec_list_dict = {}
    i = 0
    if userNum>len(user_list):
        userNum = len(user_list)
    for u in user_list[:userNum]:
        print "topK_recommend: ", i
        i += 1
        user_rec_list_dict.setdefault(u, {})
        personalized_vector_dict = {}
        biz_list = [bs[0] for bs in user_biz_star_dict[u]]
        for biz in G.nodes():
            if biz in biz_list:
                personalized_vector_dict.setdefault(biz, 1.0) # nx will do the normalization
            else:
                personalized_vector_dict.setdefault(biz, 0.0)
                
        pr_dict = nx.pagerank(G, personalization=personalized_vector_dict)
        print "get pr_dict"
        sorted_pr_list = sorted(pr_dict.items(), key = lambda x:x[1], reverse = True)
        for biz_pr in sorted_pr_list:
            biz = biz_pr[0]
            score = biz_pr[1]
            user_rec_list_dict[u].setdefault(biz, score)
    print "generate recommendations"
               
    fp2 = open(recommendation_file, 'w')
    for u in user_rec_list_dict:
        biz_score_dict = user_rec_list_dict[u]
        sorted_biz_score_list = sorted(biz_score_dict.items(), key = lambda x:x[1], reverse = True)
        for biz_score in sorted_biz_score_list[:k]:
            biz = biz_score[0]
            score = biz_score[1]
            line = '|'.join([u, biz, str(score)]) + '\n'
            fp2.write(line)
    fp2.close()
    print "finish writing the recommendations into a file"


def get_eval_results(k, recommendation_file, test_file, result_file):
    '''calculate evaluation results'''
    
    print "===get_eval_results==="
    fp1 = open(recommendation_file, 'r')
    lines = fp1.readlines()
    fp1.close()
    
    user_rec_list_dict = {}
    for line in lines:
        field_list = line.strip().split('|')
        user = field_list[0]
        biz  =field_list[1]
        if user not in user_rec_list_dict:
            user_rec_list_dict.setdefault(user, [biz])
        else:
            user_rec_list_dict[user].append(biz)
    for user in user_rec_list_dict:
        user_rec_list_dict[user] = user_rec_list_dict[user][:k]
    print "get the recommendations of each user"
    
    fp2 = open(test_file, 'r')
    lines = fp2.readlines() #user|biz
    fp2.close()
    user_testBiz_dict = {}
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        testBiz_list = field_list[1:]
        user_testBiz_dict.setdefault(user, testBiz_list)
    print "get the test biz of each user"
    
    precision = 0.0
    recall = 0.0
    for user in user_rec_list_dict:
        rec_list = user_rec_list_dict[user]
        testBiz_list = user_testBiz_dict[user]
        hitNum = len([r for r in rec_list if r in testBiz_list])
        p = float(hitNum)/k
        re = float(hitNum)/len(testBiz_list)
        precision += p
        recall += re
    precision = precision/len(user_rec_list_dict)
    recall = recall/len(user_rec_list_dict)
    
    fp3 = open(result_file, 'w')
    fp3.write("topK|precision|recall\n")
    fp3.write('|'.join([str(k), str(precision), str(recall)]) + '\n')
    print "write the eval results into a file"
    

if __name__ == '__main__':
    dir_path = r'C:\python_projects\loc_rec2\yelp_data'
    train_file = os.path.join(dir_path, 'final_train_ph.csv')
    G = construct_graph(train_file)
    dir_result_path = r'C:\python_projects\loc_rec2\yelp_data\results'    
    recommendation_file = os.path.join(dir_result_path, 'IR_recommendation_5.csv')
    userNum = 10000 # if want to eval all user； userNum = len(G.nodes())
    k = 5 # topK
    biz_file = os.path.join(dir_path, 'restaurant_in_Ph.csv')    
    user_rec_list_dict = topK_recommend(userNum, k, G, biz_file, train_file, recommendation_file)
    test_file = os.path.join(dir_path, 'final_test_ph.csv')
    result_file = os.path.join(dir_result_path, 'IR_result_5.csv')
    get_eval_results(k, recommendation_file, test_file, result_file)