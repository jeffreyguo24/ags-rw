# -*- coding: utf-8 -*-
"""
Created on Thu Jan 05 09:43:58 2017

@author: I314279
"""

import os
from nltk import ngrams
import string


def findFeaturesFromReview(features_num_dict, review):
    '''find the features appearing in a customer review
    '''
    
    features = features_num_dict.keys()
    review = review.strip()
    review =  review.translate(None, string.punctuation)
    grams = []
    nn = [1, 2, 3]
    phrases = review.split()
    for n in nn:
        n_grams = ngrams(phrases, n)
        grams.extend(n_grams)
    
    contain_features = []
    for gram in grams:
        phrase = ' '.join(gram)
        if phrase in features:
            contain_features.append(phrase)
    return contain_features


def readFeatures(lexicon_file):
    '''read the lexicon file to extract the aspects
    '''
    
    feature_num_dict = {}
    fp = open(lexicon_file, 'r')
    lines = fp.readlines()
    fp.close()
    
    for line in lines:
        field_list = line.strip().split('\t')
        feature_opinion = field_list[1]
        feature = feature_opinion.split('|')[0].replace('!','').strip()
        if feature not in feature_num_dict:
            feature_num_dict.setdefault(feature, 1)
        else:
            feature_num_dict[feature] += 1
            
    print "get the features from lexicon file"
    return feature_num_dict


def readTrainFile(feature_num_dict, train_file):
    '''read the training dataset, build user_item, user_aspect, and item_aspect
    '''
    
#    user_biz_star_dict = {}
    user_aspect_num_dict = {}
    biz_aspect_num_dict = {}
    fp2 = open(train_file, 'r')
    lines = fp2.readlines() #user|biz|star|reviews
    fp2.close()
    c=0
    for line in lines[1:]:
        if c%500 == 0: print c
        c+=1
        field_list = line.strip().split('|')
        user = field_list[0]
#        if user!='-_1ctLaz3jhPYc12hKXsEQ':continue
        biz = field_list[1]
        star = field_list[2]
        review = field_list[3]
#        # build user_biz matrix, the element is the star user rated for a biz
#        if user not in user_biz_star_dict:
#            user_biz_star_dict.setdefault(user, {biz:star})
#        else:
#            if biz not in user_biz_star_dict[user]:
#                user_biz_star_dict[user].setdefault(biz, star)
#            else: print "exist"
        # build user_aspect matrix and item_aspect matrix
        features = findFeaturesFromReview(feature_num_dict, review)
#        if "appetizers" in features: print biz
        if len(features) == 0: continue
        if user not in user_aspect_num_dict:
            for feature in features:
                user_aspect_num_dict.setdefault(user, {feature: 1})
        else:
            for feature in features:
                if feature not in user_aspect_num_dict[user]:
                    user_aspect_num_dict[user].setdefault(feature, 1)
                else:
                    user_aspect_num_dict[user][feature] += 1
        if biz not in biz_aspect_num_dict:
            for feature in features:
                biz_aspect_num_dict.setdefault(biz, {feature: 1})
        else:
            for feature in features:
                if feature not in biz_aspect_num_dict[biz]:
                    biz_aspect_num_dict[biz].setdefault(feature, 1)
                else:
                    biz_aspect_num_dict[biz][feature] += 1
    print  "finish scan train file to get user_biz_star_dict, user_aspect_num_dict, biz_aspect_num_dict"
    return (user_aspect_num_dict, biz_aspect_num_dict) 


def writeUserAspect(user_aspect_file, user_aspect_num_dict):
    '''write the user_aspect_num_dict into a file
    '''               
    
    fp = open(user_aspect_file, 'w')
    fp.write('user|aspect|num\n')
    for user in user_aspect_num_dict:
        for aspect in user_aspect_num_dict[user]:
            num = str(user_aspect_num_dict[user][aspect])
            line = '|'.join([user, aspect, num]) + '\n'
            fp.write(line)
    fp.close()
    print "finish write user_aspect"
    

def writeBizAspect(biz_aspect_file, biz_aspect_num_dict):
    '''write the biz_aspect_num_dict into a file
    '''               
    
    fp = open(biz_aspect_file, 'w')
    fp.write('biz|aspect|num\n')
    for biz in biz_aspect_num_dict:
        for aspect in biz_aspect_num_dict[biz]:
            num = str(biz_aspect_num_dict[biz][aspect])
            line = '|'.join([biz, aspect, num]) + '\n'
            fp.write(line)
    fp.close()
    print "finish write biz_aspect"
    

def writeAspectCategories(biz_aspect_file, biz_file, aspect_categories_file):
    '''get the aspect_category and write it into 
    '''
    
    #read biz aspect file
    biz_aspect_dict = {}
    fp = open(biz_aspect_file, 'r')
    lines = fp.readlines()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        biz = field_list[0]
        aspect = field_list[1]
        if biz not in biz_aspect_dict:
            biz_aspect_dict.setdefault(biz, [aspect])
        else:
            biz_aspect_dict[biz].append(aspect)
    
    aspect_biz_dict = {}
    for biz in biz_aspect_dict:
        for aspect in biz_aspect_dict[biz]:
            if aspect not in aspect_biz_dict:
                aspect_biz_dict.setdefault(aspect, [biz])
            else:
                if biz not in aspect_biz_dict[aspect]:
                    aspect_biz_dict[aspect].append(biz)
    
    biz_categories_dict = {}
    fp = open(biz_file, 'r') #biz|latitude|longitude|categories
    lines = fp.readlines()
    fp.close()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        biz = field_list[0]
        categories = field_list[-1].split(',')
        if biz not in biz_categories_dict:
            biz_categories_dict.setdefault(biz, categories)
    
    aspect_categories_dict = {}    
    for aspect in aspect_biz_dict:
        biz_list = aspect_biz_dict[aspect]
        categories = []
        for biz in biz_list:
            cate = biz_categories_dict[biz]
            categories.extend(cate)
        categories = list(set(categories))
        aspect_categories_dict.setdefault(aspect, categories)
    
    wfp = open(aspect_categories_file, 'w')
    wfp.write('aspect|categories\n')
    for aspect in aspect_categories_dict:
        categories = aspect_categories_dict[aspect]
        line = aspect + '|' + ','.join(categories) + '\n'
        wfp.write(line)
    wfp.close()
    print "finish write aspect_categories into file"


def writeAspectCategoriesHash(biz_aspect_file, biz_file, aspect_categories_file):
    '''get the aspect_category and write it into 
    '''
    
    #read biz aspect file
    biz_aspect_dict = {}
    fp = open(biz_aspect_file, 'r')
    lines = fp.readlines()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        biz = field_list[0]
        aspect = field_list[1]
        if biz not in biz_aspect_dict:
            biz_aspect_dict.setdefault(biz, [aspect])
        else:
            biz_aspect_dict[biz].append(aspect)
    
    aspect_biz_dict = {}
    for biz in biz_aspect_dict:
        for aspect in biz_aspect_dict[biz]:
            if aspect not in aspect_biz_dict:
                aspect_biz_dict.setdefault(aspect, [biz])
            else:
                if biz not in aspect_biz_dict[aspect]:
                    aspect_biz_dict[aspect].append(biz)
    
    biz_categories_dict = {}
    fp = open(biz_file, 'r') #biz|latitude|longitude|categories
    lines = fp.readlines()
    fp.close()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        biz = field_list[0]
        categories = field_list[-1].split(',')
        if biz not in biz_categories_dict:
            biz_categories_dict.setdefault(biz, categories)
    
    aspect_categories_dict = {}    
    for aspect in aspect_biz_dict:
        biz_list = aspect_biz_dict[aspect]
        categories = []
        for biz in biz_list:
            cate = biz_categories_dict[biz]
            categories.extend(cate)
        categories = list(set(categories))
        aspect_categories_dict.setdefault(aspect, categories)
    
    wfp = open(aspect_categories_file, 'w')
    wfp.write('aspect|categories\n')
    for aspect in aspect_categories_dict:
        categories = aspect_categories_dict[aspect]
        cate_hash = [str(hash(c)) for c in categories]
        line = aspect + '|' + ','.join(cate_hash) + '\n'
        wfp.write(line)
    wfp.close()
    print "finish write aspect_categories into file"
    

if __name__ == '__main__':
    dir_path = r'C:\python_projects\loc_rec2\yelp_data3'
    
    train_file = os.path.join(dir_path, 'final_train_lv.csv') #sample
    friends_file = os.path.join(dir_path, 'friends_lv.csv') #sample
    lexicon_file = os.path.join(dir_path, 'review.lv.lexicon')

    user_aspect_file = os.path.join(dir_path, 'user_aspect.csv')    
    biz_aspect_file = os.path.join(dir_path, 'biz_aspect.csv')
    
#    feature_num_dict = readFeatures(lexicon_file)
#    matrices = readTrainFile(feature_num_dict, train_file)
#    user_aspect_num_dict, biz_aspect_num_dict = matrices
    
#    writeUserAspect(user_aspect_file, user_aspect_num_dict)
#    writeBizAspect(biz_aspect_file, biz_aspect_num_dict)
    
    biz_file = os.path.join(dir_path, 'restaurant_in_lv.csv')
    aspect_categories_file = os.path.join(dir_path, 'aspect_categories.csv')
    aspect_categories_hash_file = os.path.join(dir_path, 'aspect_categories_hash.csv')
#    writeAspectCategories(biz_aspect_file, biz_file, aspect_categories_file)
    writeAspectCategoriesHash(biz_aspect_file, biz_file, aspect_categories_hash_file)
    
    
    