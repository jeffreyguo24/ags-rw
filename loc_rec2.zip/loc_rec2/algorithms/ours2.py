# -*- coding: utf-8 -*-
"""
Created on Sat Jan 07 14:51:38 2017

@author: I314279
"""

import os
import igraph as ig
from math import pi, sqrt, cos, sin, asin, e
import time
import pickle


def compute_geodist(lat1, lon1, lat2, lon2):
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137
    

def get_similarity(biz_star_list1, biz_star_list2):
    '''get the cosine similarity of two users'''
    
    cos_sim = 0.0; upper = 0.0; 
    divider = 0.0
    biz_star_dict1 = {}
    biz_star_dict2 = {}
    for bs in biz_star_list1:
        b = bs[0]
        s = bs[1]
        biz_star_dict1.setdefault(b, s)
    for bs in biz_star_list2:
        b = bs[0]
        s = bs[1]
        biz_star_dict2.setdefault(b, s)
    for biz_id in biz_star_dict1:
        if biz_id in biz_star_dict2: # if user2 also visited biz
            upper += (float(biz_star_dict1[biz_id]) * float(biz_star_dict2[biz_id]))
    if upper == 0:
        return 0
    w_square_sum1 = 0.0
    for biz_id in biz_star_dict1:
        w_square_sum1 += float(biz_star_dict1[biz_id]) ** 2
    w_square_sum2 = 0.0
    for biz_id in biz_star_dict2:
        w_square_sum2 += float(biz_star_dict2[biz_id]) ** 2
    divider = (w_square_sum1 ** 0.5) * (w_square_sum2 ** 0.5)
    cos_sim = upper / divider
    return cos_sim

    
def get_similarity_aspects(aspect_categories_dict, aspect1, aspect2):
    '''get the similarity between aspects
    '''
    
    cate_list1 = aspect_categories_dict[aspect1]
    cate_list2 = aspect_categories_dict[aspect2]
    overlap = [c for c in cate_list1 if c in cate_list2]
    cate_list1.extend(cate_list2)
    union = list(set(cate_list1))
    return float(len(overlap)) / len(union)    
    

def readFriendFile(friends_file):
    '''read friend file and return user_friend_dict
    '''
    
    user_friends_dict = {}
    fp1 = open(friends_file, 'r')
    lines = fp1.readlines() #user|friend1, friend2,...
    fp1.close()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        friends = field_list[1].split(',')
        if user not in user_friends_dict:
            if friends == ['']:
                friends = []
            user_friends_dict.setdefault(user, friends)
        else:
            for f in friends:
                if f not in user_friends_dict[user]:
                    user_friends_dict[user].append(f)
        for f in friends:
            if f not in user_friends_dict:
                user_friends_dict.setdefault(f, [user])
            else:
                if user not in user_friends_dict[f]:
                    user_friends_dict[f].append(user)
    print "finish scan friends file"
    return user_friends_dict

    

def readTrainFile(train_file):
    '''read train file and return user_biz_star_dict
    '''
    user_biz_star_dict = {}
    user_list, biz_list = [], []
    fp2 = open(train_file, 'r')
    lines = fp2.readlines() #user|biz|star|reviews
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        biz = field_list[1]
        if user not in user_list: user_list.append(user)
        if biz not in biz_list: biz_list.append(biz)
        star = field_list[2]
        if user not in user_biz_star_dict:
            user_biz_star_dict.setdefault(user, [(biz, star)])
        else:
            user_biz_star_dict[user].append((biz, star))
    fp2.close()
    return user_biz_star_dict, set(user_list), set(biz_list)
    print  "finish scan train file"
    

def readUserAspectFile(user_aspect_num_file):
    '''read user_aspect_file and return user_aspect_dict
    '''
    
    user_aspect_num_dict = {}
    aspect_list = []
    fp = open(user_aspect_num_file, 'r')
    lines = fp.readlines() #user|aspect|num
    fp.close()
    
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        aspect = field_list[1]
        if aspect not in aspect_list: aspect_list.append(aspect)
        num = field_list[2]
        if user not in user_aspect_num_dict:
            user_aspect_num_dict.setdefault(user, {aspect: num})
        else:
            if aspect not in user_aspect_num_dict[user]:
                user_aspect_num_dict[user].setdefault(aspect, num)
    print "finish read user aspect file"
    return user_aspect_num_dict, set(aspect_list)
    

def readBizAspectFile(biz_aspect_num_file):
    '''read biz_aspect_file and return biz_aspect_dict
    '''
    
    biz_aspect_num_dict = {}
    fp = open(biz_aspect_num_file, 'r')
    lines = fp.readlines() #biz|aspect|num
    fp.close()
    
    for line in lines[1:]:
        field_list = line.strip().split('|')
        biz = field_list[0]
        aspect = field_list[1]
        num = field_list[2]
        if biz not in biz_aspect_num_dict:
            biz_aspect_num_dict.setdefault(biz, {aspect: num})
        else:
            if aspect not in biz_aspect_num_dict[biz]:
                biz_aspect_num_dict[biz].setdefault(aspect, num)
    print "finish read biz aspect file"
    return biz_aspect_num_dict
    
    
def readAspectCategoriesFile(aspect_categories_file):
    '''read aspect categories file and return aspect_categories_dict
    '''
    
    aspect_categories_dict = {}
    fp = open(aspect_categories_file, 'r')
    lines = fp.readlines() #aspect|category1|category2...
    fp.close()
    
    for line in lines[1:]:
        field_list = line.strip().split('|')
        aspect = field_list[0]
        categories = field_list[1].split(',')
        if aspect not in aspect_categories_dict:
            aspect_categories_dict.setdefault(aspect, categories)
    print "finish read aspect categories file"
    return aspect_categories_dict
    
    
def readBizFile(biz_file):
    '''read biz file and return biz_lat_lon_dict
    '''
    
    biz_lat_lon_dict = {}
    fp2 = open(biz_file, 'r')
    lines = fp2.readlines() #biz|latitude|longitude|categories
    fp2.close()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        biz = field_list[0]
        lat = field_list[1]
        lon = field_list[2]
        biz_lat_lon_dict.setdefault(biz, (lat, lon))
    print "finish scan biz file"
    return biz_lat_lon_dict


def normalization(diction):
    '''normalize the weight for all relation stored in this dictionary
    '''
    x_sum_dict = {}
    for rel in diction:
        x1, x2, w0 = rel[0], rel[1], float(diction[rel])
        if x1 not in x_sum_dict:
            x_sum_dict.setdefault(x1, w0)
        else:x_sum_dict[x1] += w0
        if x2 not in x_sum_dict:
            x_sum_dict.setdefault(x2, w0)
        else:x_sum_dict[x2] += w0

    norm_rel_dict = {}
    for rel in diction:
        x1, x2, w0 = rel[0], rel[1], diction[rel] 
        w_x1_x2 = float(w0) / x_sum_dict[x1]
        w_x2_x1 = float(w0) / x_sum_dict[x2]
        norm_rel_dict.setdefault((x1, x2), w_x1_x2)
        norm_rel_dict.setdefault((x2, x1), w_x2_x1)
    return norm_rel_dict
    # return diction


def construct_graph_ig(setFriends, setAspects, setBizs, user_set, biz_set, \
                        aspect_set, biz_lat_lon_dict, user_biz_star_dict, \
                        user_friends_dict, user_aspect_num_dict, \
                        biz_aspect_num_dict, aspect_categories_dict, pkl_file):
    '''construct graph from train and friends datastet
    '''   
    
    print "=====construct graph====="

    G = ig.Graph(directed=True)
    vertices = []
    for user in user_set:
        vertices.append(user)
    for biz in biz_set:
        vertices.append(biz)
    for aspect in aspect_set:
        vertices.append(aspect)
    vertices = list(set(vertices))
    train_aspect_list = []
    user_aspect_w_dict = {}
    user_biz_w_dict = {}
    user_user_w_dict = {}
    n = 0
    for user1 in user_set:
        # print n
        biz_star_list1 = user_biz_star_dict[user1]
        #set weight between user and biz
        for bs in biz_star_list1:
            user_biz_w_dict.setdefault((user1, bs[0]), bs[1])
        aspect_num_dict = user_aspect_num_dict[user1]
        #set weight between user and aspect
        for aspect in aspect_num_dict:
            user_aspect_w_dict.setdefault((user1, aspect), aspect_num_dict[aspect])
            if aspect not in train_aspect_list: train_aspect_list.append(aspect)
        #set weight between friends
        if setFriends:
            friends = user_friends_dict[user1]
            friends = [f for f in friends if f!='']
            if friends == []:
                continue
            # set weight between friend
            for user2 in user_biz_star_dict:
                if user1 == user2:
                    continue
                biz_star_list2 = user_biz_star_dict[user2]
                similarity = get_similarity(biz_star_list1, biz_star_list2)
                # if user2 in user_friends_dict[user1]:
                #     w = 0.3*(1/float(len(friends))) + 0.7*similarity
                # else:
                #     if similarity == 0:
                #         continue                    
                #     w = similarity
                w = similarity
                user_user_w_dict.setdefault((user1, user2), w)
        n += 1

    user_aspect_w_dict = normalization(user_aspect_w_dict)
    user_biz_w_dict = normalization(user_biz_w_dict)
    user_user_w_dict = normalization(user_user_w_dict)

    # vertices.extend(train_aspect_list)
    G.add_vertices(vertices)

    #set weight between biz and aspect
    # aspect_in_biz = []
    biz_aspect_w_dict = {}
    for biz in biz_set:
        aspect_num_dict = biz_aspect_num_dict[biz]
        for aspect in aspect_num_dict:
            # if aspect not in aspect_in_biz: aspect_in_biz.append(aspect)
            if aspect not in train_aspect_list: continue  # exclude aspects not having been rated by users
            num = aspect_num_dict[aspect]
            biz_aspect_w_dict.setdefault((biz, aspect), num)
    biz_aspect_w_dict = normalization(biz_aspect_w_dict)
    print "set the weight between biz and aspect"
    
    # set weight between aspects
    aspect_aspect_w_dict = {}
    if setAspects == True:
        for aspect1 in train_aspect_list: 
            for aspect2 in train_aspect_list:
                if aspect1 == aspect2: continue
                tt = time.time()
                w = get_similarity_aspects(aspect_categories_dict, aspect1, aspect2)
                print "compute weight between aspect", time.time() - tt
                if w == 0.0: continue                
                aspect_aspect_w_dict.setdefault((aspect1, aspect2), w)
        aspect_aspect_w_dict = normalization(aspect_aspect_w_dict)
        print "set weight between aspects"
    
    # set the weight between bizs
    biz_biz_w_dict = {}
    if setBizs == True:
        with open(pkl_file, 'rb') as f:
            reg = pickle.load(f) 
        for biz1 in biz_set:
            lat1 = float(biz_lat_lon_dict[biz1][0])
            lon1 = float(biz_lat_lon_dict[biz1][1])
            for biz2 in biz_set:
                if biz1 == biz2: continue
                lat2 = float(biz_lat_lon_dict[biz2][0])
                lon2 = float(biz_lat_lon_dict[biz2][1])
                distance = compute_geodist(lat1, lon1, lat2, lon2)
                w = e ** (reg.predict(distance)[0])
                biz_biz_w_dict.setdefault((biz1, biz2), w)
        biz_biz_w_dict = normalization(biz_biz_w_dict)
        print "set the weight between bizs"          
    
    print "start add edges"
    edges_w_dict = user_biz_w_dict.copy()
    for relation in (user_aspect_w_dict, biz_aspect_w_dict, user_user_w_dict, biz_biz_w_dict, aspect_aspect_w_dict):
        edges_w_dict.update(relation)
    edges_w_dict = normalization(edges_w_dict)
    G.es['weight'] = 1.0 #weighted graph
    edges = edges_w_dict.keys() 
    G.add_edges(edges)
    for eid in range(len(edges)):
        G.es[eid]['weight'] = edges_w_dict[edges[eid]]
    return G, vertices
    print "===construct_graph==="
   

def topK_recommend_ig(userNum, k, G, user_set, biz_set, aspect_set, recommendation_file):
    '''this method is to run personalized pagerank'''    
    
    print "===topK_recommend==="
    allNodes = [v['name'] for v in G.vs]
    users = [v['name'] for v in G.vs if v['name'] in user_set]
    bizs = [v['name'] for v in G.vs if v['name'] in biz_set]
    aspects = [v['name'] for v in G.vs if v['name'] in aspect_set]
    user_rec_list_dict = {}
    i = 0
    if userNum > len(users):
        userNum = len(users)
    print "user number: ", userNum
    for u in users[:userNum]:
        print "topK_recommend: ", i
        t = time.time()
        i += 1
        user_rec_list_dict.setdefault(u, {})
        reset_vertices = [users.index(u)] # personalization
        pr_list = G.personalized_pagerank(directed=True, reset_vertices = reset_vertices, weights="weight")
        pr_dict = {}
        for j in range(len(allNodes)):
            pr_dict.setdefault(allNodes[j], pr_list[j])
        print "get pr_dict"
        t1 = time.time()
        print t1 - t
        sorted_pr_list = sorted(pr_dict.items(), key = lambda x:x[1], reverse = True)       
        for s in sorted_pr_list:
            entity = s[0]
            score = s[1]
            if entity in bizs:
                user_rec_list_dict[u].setdefault(entity, score)
        t2 = time.time()
        print t2 - t1
    print "generate recommendations"
    
    fp3 = open(recommendation_file, 'w')
    for u in user_rec_list_dict:
        biz_score_dict = user_rec_list_dict[u]
        sorted_biz_score_list = sorted(biz_score_dict.items(), key = lambda x:x[1], reverse = True)
        for biz_score in sorted_biz_score_list[:k]:
            biz = biz_score[0]
            score = biz_score[1]
            line = '|'.join([u, biz, str(score)]) + '\n'
            fp3.write(line)
    fp3.close()
    print "finish writing the recommendations into a file"


def get_eval_results(k, recommendation_file, test_file, result_file):
    '''calculate evaluation results'''
    
    print "===get_eval_results ", "k = ", k, "==="
    fp1 = open(recommendation_file, 'r')
    lines = fp1.readlines()
    fp1.close()
    
    user_rec_list_dict = {}
    for line in lines:
        field_list = line.strip().split('|')
        user = field_list[0]
        biz  =field_list[1]
        if user not in user_rec_list_dict:
            user_rec_list_dict.setdefault(user, [biz])
        else:
            user_rec_list_dict[user].append(biz)
    for user in user_rec_list_dict:
        user_rec_list_dict[user] = user_rec_list_dict[user][:k]
    print "get the recommendations of each user"
    
    fp2 = open(test_file, 'r')
    lines = fp2.readlines() #user|biz
    fp2.close()
    user_testBiz_dict = {}
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        testBiz_list = field_list[1:]
        user_testBiz_dict.setdefault(user, testBiz_list)
    print "get the test biz of each user"
    
    precision = 0.0
    recall = 0.0
    m = 0
    for user in user_rec_list_dict:
        rec_list = user_rec_list_dict[user]
        #user_testBiz_dict does not have user in ed case
        if user not in user_testBiz_dict:
            m+=1
            continue
        testBiz_list = user_testBiz_dict[user]
        hitNum = len([r for r in rec_list if r in testBiz_list])
        p = float(hitNum)/k
        re = float(hitNum)/len(testBiz_list)
        precision += p
        recall += re
    precision = precision/(len(user_rec_list_dict)-m)
    recall = recall/(len(user_rec_list_dict)-m)
    
    fp3 = open(result_file, 'w')
    fp3.write("topK|precision|recall\n")
    fp3.write('|'.join([str(k), str(precision), str(recall)]) + '\n')
    print "write the eval results into a file"
    

if __name__ == '__main__':

    sample = True

    if not sample:
        dir_path = '/home/I314279/python_projects/loc_rec2/yelp_data'
        train_file = os.path.join(dir_path, 'final_train_ph.csv') #sample
        friends_file = os.path.join(dir_path, 'friends_ph.csv') #sample
        user_aspect_num_file = os.path.join(dir_path, 'user_aspect.csv')
        biz_aspect_num_file = os.path.join(dir_path, 'biz_aspect.csv')
        aspect_categories_file = os.path.join(dir_path, 'aspect_categories.csv')
        biz_file = os.path.join(dir_path, 'restaurant_in_ph.csv')

        biz_lat_lon_dict = readBizFile(biz_file)
        user_friends_dict = readFriendFile(friends_file)
        user_biz_star_dict, user_set, biz_set = readTrainFile(train_file)
        user_aspect_num_dict, aspect_set = readUserAspectFile(user_aspect_num_file)
        biz_aspect_num_dict = readBizAspectFile(biz_aspect_num_file)
        aspect_categories_dict = readAspectCategoriesFile(aspect_categories_file)

        t = time.time()
        pkl_file = os.path.join(dir_path, 'regression_ph_2.pkl')
        setFriends, setAspects, setBizs = True, False, False
        G, V = construct_graph_ig(setFriends, setAspects, setBizs, user_set, biz_set, \
                                aspect_set, biz_lat_lon_dict, user_biz_star_dict, \
                                user_friends_dict, user_aspect_num_dict, \
                                biz_aspect_num_dict, aspect_categories_dict, pkl_file)
        
        t1 = time.time()
        print t1 - t
        print "num of nodes, edges", G.vcount(), G.ecount()   
        
        userNum = 20000 # if want to eval all user； userNum = len(G.nodes())
        k = 30 # topK
       
        dir_result_path = '/home/I314279/python_projects/loc_rec2/yelp_data/results' 
        recommendation_file = os.path.join(dir_result_path, 'ours_recommendation_15.csv')
        # run recommendation algorithm
        user_rec_list_dict = topK_recommend_ig(userNum, k, G, user_set, biz_set, aspect_set, recommendation_file)
        test_file = os.path.join(dir_path, 'final_test_ph.csv') #sample

        for k in [5, 10, 20]:
            result_file = os.path.join(dir_result_path, 'ours_result_' + str(k) + '.csv') #sample
            get_eval_results(k, recommendation_file, test_file, result_file)

    else:
        dir_path = r'C:\python_projects\loc_rec2\yelp_data'
        train_file = os.path.join(dir_path, 'final_sample_train_ph.csv') #sample
        friends_file = os.path.join(dir_path, 'sample_friends_ph.csv') #sample
        user_aspect_num_file = os.path.join(dir_path, 'user_aspect.csv')
        biz_aspect_num_file = os.path.join(dir_path, 'biz_aspect.csv')
        aspect_categories_file = os.path.join(dir_path, 'aspect_categories.csv')
        biz_file = os.path.join(dir_path, 'restaurant_in_ph.csv')

        biz_lat_lon_dict = readBizFile(biz_file)
        user_friends_dict = readFriendFile(friends_file)
        user_biz_star_dict, user_set, biz_set = readTrainFile(train_file)
        user_aspect_num_dict, aspect_set = readUserAspectFile(user_aspect_num_file)
        biz_aspect_num_dict = readBizAspectFile(biz_aspect_num_file)
        aspect_categories_dict = readAspectCategoriesFile(aspect_categories_file)

        t = time.time()
        pkl_file = os.path.join(dir_path, 'regression_ph_2.pkl')
        setFriends, setAspects, setBizs = False, False, False
        G, V = construct_graph_ig(setFriends, setAspects, setBizs, user_set, biz_set, \
                                aspect_set, biz_lat_lon_dict, user_biz_star_dict, \
                                user_friends_dict, user_aspect_num_dict, \
                                biz_aspect_num_dict, aspect_categories_dict, pkl_file)
        
        t1 = time.time()
        print t1 - t
        print "num of nodes, edges", G.vcount(), G.ecount()   
        
        userNum = 100 # if want to eval all user； userNum = len(G.nodes())
        k = 30 # topK
       
        dir_result_path = r'C:\python_projects\loc_rec2\yelp_data4\results' 
        recommendation_file = os.path.join(dir_result_path, 'ours_recommendation_sample_30.csv')
        # run recommendation algorithm
        user_rec_list_dict = topK_recommend_ig(userNum, k, G, user_set, biz_set, aspect_set, recommendation_file)
        test_file = os.path.join(dir_path, 'final_sample_test_ph.csv') #sample

        for k in [5, 10, 15, 20]:
            result_file = os.path.join(dir_result_path, 'ours_result_sample_' + str(k) + '.csv') #sample
            get_eval_results(k, recommendation_file, test_file, result_file)
    
    