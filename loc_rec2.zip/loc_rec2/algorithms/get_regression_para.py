# -*- coding: utf-8 -*-
"""
Created on Fri Jan 06 17:23:21 2017

@author: I314279
"""


import os
from sklearn import linear_model
from math import pi, sqrt, cos, sin, asin, log
import matplotlib.pyplot as plt

def compute_geodist(lat1, lon1, lat2, lon2):
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137
    

#lat1 = 35.089035
#lon1 = -80.8670549
#lat2 = 35.2274621
#lon2 = -80.8388937
#
#print compute_geodist(lat1, lon1, lat2, lon2)

city = 'lv'
digit_num = 1
digit_num_dict = {0: 1.0, 1: 0.1, 2: 0.01}
dir_path = r'C:\python_projects\loc_rec2\yelp_data3'

biz_file = os.path.join(dir_path, 'restaurant_in_lv.csv')
train_file = os.path.join(dir_path, 'final_train_lv.csv') #sample

biz_lat_lon_dict = {}
fp2 = open(biz_file, 'r')
lines = fp2.readlines() #biz|latitude|longitude|categories
fp2.close()
for line in lines[1:]:
    field_list = line.strip().split('|')
    biz = field_list[0]
    lat = field_list[1]
    lon = field_list[2]
    biz_lat_lon_dict.setdefault(biz, (lat, lon))
print "finish scan biz file" 

user_biz_dict = {}
fp1 = open(train_file, 'r')
lines = fp1.readlines() #user|biz|star|reviews
fp1.close()
for line in lines[1:]:
    field_list = line.strip().split('|')
    user = field_list[0]
    biz = field_list[1]
    if user not in user_biz_dict:
        user_biz_dict.setdefault(user, [biz])
    else:
        user_biz_dict[user].append(biz)
print  "finish scan train file"

distance_num_dict = {}
total_num = 0
for user in user_biz_dict:
    biz_list = user_biz_dict[user]
    for biz1 in biz_list:
        lat1 = float(biz_lat_lon_dict[biz1][0])
        lon1 = float(biz_lat_lon_dict[biz1][1])
        for biz2 in biz_list:
            if biz1==biz2: continue
            lat2 = float(biz_lat_lon_dict[biz2][0])
            lon2 = float(biz_lat_lon_dict[biz2][1])
            distance = compute_geodist(lat1, lon1, lat1, lon2)
            distance = round(distance, digit_num)
            if distance == 0: distance = digit_num_dict[digit_num]
            distance = str(distance)
            if distance not in distance_num_dict:
                distance_num_dict.setdefault(distance, 1)
            else:
                distance_num_dict[distance] += 1
print "finish distance num dict"

distance_list = [float(distance) for distance in distance_num_dict.keys()]
distance_log = [log(distance) for distance in distance_list]
distance_x = [[d] for d in distance_log]

num_list = [distance_num_dict[str(distance)] for distance in distance_list]
total_num = sum(num_list)
prob_list = [float(num) / total_num for num in num_list]

prob_log = [log(prob) for prob in prob_list]
reg = linear_model.Ridge (alpha = .1)
 
reg.fit(distance_x, prob_log)
predict = reg.predict(distance_x)

plt.scatter(distance_x, prob_log,  color='black')
plt.plot(distance_x, predict, color='blue', linewidth=3)

plt.show()

import pickle
filename = 'regression_' + city + '_' + str(digit_num) + '.pkl'
with open(filename, 'wb') as f:
    pickle.dump(reg, f) 
