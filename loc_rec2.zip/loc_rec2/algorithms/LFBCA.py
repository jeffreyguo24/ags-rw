# -*- coding: utf-8 -*-
"""
Created on Thu Dec 22 15:32:08 2016

@author: QGUO006
"""

import os
import networkx as nx
from math import pi, sqrt, cos, sin, asin, acos, ceil, log, floor

def compute_geodist(lat1, lon1, lat2, lon2):
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137
    

def get_similarity(biz_star_list1, biz_star_list2):
    '''get the cosine similarity of two users'''
    
    cos_sim = 0.0; upper = 0.0; 
    divider = 0.0
    biz_star_dict1 = {}
    biz_star_dict2 = {}
    for bs in biz_star_list1:
        b = bs[0]
        s = bs[1]
        biz_star_dict1.setdefault(b, s)
    for bs in biz_star_list2:
        b = bs[0]
        s = bs[1]
        biz_star_dict2.setdefault(b, s)
    for biz_id in biz_star_dict1:
        if biz_id in biz_star_dict2: # if user2 also visited biz
            upper += (float(biz_star_dict1[biz_id]) * float(biz_star_dict2[biz_id]))
    if upper == 0:
        return 0
#    print 'upper', upper
    # get divider
    w_square_sum1 = 0.0
    for biz_id in biz_star_dict1:
        w_square_sum1 += float(biz_star_dict1[biz_id]) ** 2
    w_square_sum2 = 0.0
    for biz_id in biz_star_dict2:
        w_square_sum2 += float(biz_star_dict2[biz_id]) ** 2
    divider = (w_square_sum1 ** 0.5) * (w_square_sum2 ** 0.5)
    # get the similarity
    cos_sim = upper / divider
#    print 'divider', divider
    return cos_sim


def construct_graph(train_file, user_friends_dict):
    "construct graph from train and friends datastet"
    
    print "===construct_graph==="
    user_friends_dict = {}
    fp1 = open(friends_file, 'r')
    lines = fp1.readlines()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        friends = field_list[1].split(',')
        if user not in user_friends_dict:
            if friends == ['']:
                friends = []
            user_friends_dict.setdefault(user, friends)
        else:
            for f in friends:
                if f not in user_friends_dict[user]:
                    user_friends_dict[user].append(f)
        for f in friends:
            if f not in user_friends_dict:
                user_friends_dict.setdefault(f, [user])
            else:
                if user not in user_friends_dict[f]:
                    user_friends_dict[f].append(user)
    fp1.close()
    print "finish scan friends file"
    
    user_biz_star_dict = {}
    fp2 = open(train_file, 'r')
    lines = fp2.readlines() #user|biz|star|reviews
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        biz = field_list[1]
        star = field_list[2]
        if user not in user_biz_star_dict:
            user_biz_star_dict.setdefault(user, [(biz, star)])
        else:
            user_biz_star_dict[user].append((biz, star))
    fp2.close()
    print  "finish scan train file"

    G = nx.DiGraph()
    for user1 in user_biz_star_dict:
        biz_star_list1 = user_biz_star_dict[user1]
        friends = user_friends_dict[user1]
        friends = [f for f in friends if f!='']
#        if user1 == 'xZvRLPJ1ixhFVomkXSfXAw':
#            print friends
        if friends == []:
            continue
        for user2 in user_biz_star_dict:
            if user1 == user2:
                continue
            biz_star_list2 = user_biz_star_dict[user2]
            similarity = get_similarity(biz_star_list1, biz_star_list2)
            if user2 in user_friends_dict[user1]:
                w = 0.3*(1/float(len(friends))) + 0.7*similarity
            else:
                if similarity == 0:
                    continue                    
                w = similarity
            G.add_edge(user1, user2, weight = w)
    return G

 
def topK_recommend(userNum, k, dist, G, biz_file, train_file, recommendation_file):
    '''this method is to run personalized pagerank'''    
    
    print "===topK_recommend==="
    user_biz_star_dict = {}
    fp1 = open(train_file, 'r')
    lines = fp1.readlines() #user|biz|star|reviews
    fp1.close()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        biz = field_list[1]
        star = field_list[2]
        if user not in user_biz_star_dict:
            user_biz_star_dict.setdefault(user, [(biz, star)])
        else:
            user_biz_star_dict[user].append((biz, star))
    print  "finish scan train file"
    
    biz_lat_lon_dict = {}
    fp2 = open(biz_file, 'r')
    lines = fp2.readlines() #biz|latitude|longitude|categories
    fp2.close()
    for line in lines[1:]:
        field_list = line.strip().split('|')
        biz = field_list[0]
        lat = field_list[1]
        lon = field_list[2]
        biz_lat_lon_dict.setdefault(biz, (lat, lon))
    print "finish scan biz file"
    
    users = G.nodes()
    user_rec_list_dict = {}
    i = 0
    if userNum>len(users):
        userNum = len(users)
    for u in users[:userNum]:
        print "topK_recommend: ", i
        i += 1
        user_rec_list_dict.setdefault(u, {})
        personalized_vector_dict = {}
        for u2 in users:
            if u2 == u:
                personalized_vector_dict.setdefault(u2, 1.0)
            else:
                personalized_vector_dict.setdefault(u2, 0.0)
        pr_dict = nx.pagerank(G, personalization=personalized_vector_dict)
        print "get pr_dict"
        sorted_pr_list = sorted(pr_dict.items(), key = lambda x:x[1], reverse = True)
        for other in sorted_pr_list:
            u3 = other[0]
            pr = other[1]
            for biz_star in user_biz_star_dict[u3]:
                biz = biz_star[0]
                lat1 = float(biz_lat_lon_dict[biz][0])
                lon1 = float(biz_lat_lon_dict[biz][1])
                min_distance = 100000.0
                for biz_star2 in user_biz_star_dict[u]:
                    biz2 = biz_star2[0]
                    lat2 = float(biz_lat_lon_dict[biz2][0])
                    lon2 = float(biz_lat_lon_dict[biz2][1])
                    distance = compute_geodist(lat1, lon1, lat2, lon2)
                    if distance < min_distance:
                        min_distance = distance
                if min_distance > dist:
                    continue
                star = float(biz_star[1])
                if biz not in user_rec_list_dict[u]:
                    score = pr*star
                    user_rec_list_dict[u].setdefault(biz, score)
                else:
                    user_rec_list_dict[u][biz] += pr*star
    print "generate recommendations"
    
    fp3 = open(recommendation_file, 'w')
    for u in user_rec_list_dict:
        biz_score_dict = user_rec_list_dict[u]
        sorted_biz_score_list = sorted(biz_score_dict.items(), key = lambda x:x[1], reverse = True)
        for biz_score in sorted_biz_score_list[:k]:
            biz = biz_score[0]
            score = biz_score[1]
            line = '|'.join([u, biz, str(score)]) + '\n'
            fp3.write(line)
    fp3.close()
    print "finish writing the recommendations into a file"


def get_eval_results(k, recommendation_file, test_file, result_file):
    '''calculate evaluation results'''
    
    print "===get_eval_results==="
    fp1 = open(recommendation_file, 'r')
    lines = fp1.readlines()
    fp1.close()
    
    user_rec_list_dict = {}
    for line in lines:
        field_list = line.strip().split('|')
        user = field_list[0]
        biz  =field_list[1]
        if user not in user_rec_list_dict:
            user_rec_list_dict.setdefault(user, [biz])
        else:
            user_rec_list_dict[user].append(biz)
    for user in user_rec_list_dict:
        user_rec_list_dict[user] = user_rec_list_dict[user][:k]
    print "get the recommendations of each user"
    
    fp2 = open(test_file, 'r')
    lines = fp2.readlines() #user|biz
    fp2.close()
    user_testBiz_dict = {}
    for line in lines[1:]:
        field_list = line.strip().split('|')
        user = field_list[0]
        testBiz_list = field_list[1:]
        user_testBiz_dict.setdefault(user, testBiz_list)
    print "get the test biz of each user"
    
    precision = 0.0
    recall = 0.0
    for user in user_rec_list_dict:
        rec_list = user_rec_list_dict[user]
        testBiz_list = user_testBiz_dict[user]
        hitNum = len([r for r in rec_list if r in testBiz_list])
        p = float(hitNum)/k
        re = float(hitNum)/len(testBiz_list)
        precision += p
        recall += re
    precision = precision/len(user_rec_list_dict)
    recall = recall/len(user_rec_list_dict)
    
    fp3 = open(result_file, 'w')
    fp3.write("topK|precision|recall\n")
    fp3.write('|'.join([str(k), str(precision), str(recall)]) + '\n')
    print "write the eval results into a file"
    

if __name__ == '__main__':
    dir_path = r'C:\python_projects\loc_rec2\yelp_data'
    train_file = os.path.join(dir_path, 'final_train_ph.csv') #sample
    friends_file = os.path.join(dir_path, 'friends_ph.csv') #sample
    G = construct_graph(train_file, friends_file)
    dir_result_path = r'C:\python_projects\loc_rec2\yelp_data\results'    
    recommendation_file = os.path.join(dir_result_path, 'LFBCA_recommendation.csv') #sample
    userNum = 20000 # if want to eval all user； userNum = len(G.nodes())
    k = 10 # topK
    dist = 2
    biz_file = os.path.join(dir_path, 'restaurant_in_Ph.csv')    
    user_rec_list_dict = topK_recommend(userNum, k, dist, G, biz_file, train_file, recommendation_file)
    test_file = os.path.join(dir_path, 'final_test_ph.csv') #sample
    result_file = os.path.join(dir_result_path, 'LFBCA_result.csv') #sample
    get_eval_results(k, recommendation_file, test_file, result_file)
    
    